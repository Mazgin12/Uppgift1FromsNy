﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KassaSystemWindowsForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        // Metod för att räkna ut rest
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Deklarera variabler för köpbelopp och betalningssumma
            int tal1 = Convert.ToInt32(tal1Value.Text);
            int tal2 = Convert.ToInt32(tal2Value.Text);

            // Ifall Köpbeloppet överstiger betalningssumman kan programmet ej genomföras då pengarna inte räcker till
            if (tal1 > tal2)
            {
                restResultat.Text = "Betalningssuman är otillräcklig!";
            }
            else
            {
                // räkna ut rest
                int rest = tal2 - tal1;
                restResultat.Text = "Rest att betala tillbaka: " + rest + " kr";

                // sedlar och mynt
                calculateRest(ref rest, 500, "sedlar");
                calculateRest(ref rest, 200, "sedlar");
                calculateRest(ref rest, 100, "sedlar");
                calculateRest(ref rest, 50, "sedlar");
                calculateRest(ref rest, 20, "sedlar");
                calculateRest(ref rest, 10, "mynt");
                calculateRest(ref rest, 5, "mynt");
                calculateRest(ref rest, 1, "mynt");



                // Om rest är större än noll skrivs den ut
                if (rest > 0)
                {
                    restResultat.Text += "\nRest: " + rest;
                }

                // Visar resultatet av resten på skärmen i form av sedlar och mynt samt antal
                void calculateRest(ref int restchange, int denomination, string label)
                {
                    int numDenomination = rest / denomination;
                    if (numDenomination > 0)
                    {

                        restchange %= denomination;
                        restResultat.Text += " " +
                            "\nav " + denomination + " " + label + ": " + numDenomination + "\n";
                    }
                }
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tal1_Click(object sender, EventArgs e)
        {

        }

        private void tal2_Click(object sender, EventArgs e)
        {

        }

        private void tal1Value_TextChanged(object sender, EventArgs e)
        {

        }

        private void tal2Value_TextChanged(object sender, EventArgs e)
        {

        }

        private void restResultat_Click(object sender, EventArgs e)
        {

        }

        private void closeProgram_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
